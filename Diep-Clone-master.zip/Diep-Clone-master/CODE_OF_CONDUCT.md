1. Do not abuse the issue reporting system.
2. Do not abuse the pull request system.
3. Do not create issues on unfinished files.
4. Do not spam, troll, etc.
5. Do not disrupt the project.
6. Do not ask when the next release is, we can't give a date.
7. Please join <https://discord.gg/BwqMNRn> if you have any questions.
