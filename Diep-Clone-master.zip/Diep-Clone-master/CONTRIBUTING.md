Rules and Guidelines:
  1. Do not spam issues.
  2. Do not spam pull requests.
  3. Do not attempt to sneak code into the project.
  4. Do not disrupt the project.
  5. Please comment your code, preferably with JSDoc tags, if possible.

ANYONE NOT FOLLOWING THESE RULES WILL BE BANNED FROM CONTRIBUTING!!!
