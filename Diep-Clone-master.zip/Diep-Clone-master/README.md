# Diep-Clone

This is an open-source clone of http://diep.io

Please join us at https://discord.gg/BwqMNRn for more information.
